# projeto_snct
Os arquivos cancelarReserva, reservarSala e reservas ainda não foram feitos pelos outros membros da equipe. O pessoal do css ainda estão decidindo sobre a tematica e tentando entra em acordo para ver como que vai ser toda a parte visual do projeto(se bem que esse não vai ser apresentado na SNCT 'eu acho').

Fora isso, o restante dos códigos estão funcionando (create e read) provavelmente ele saia com um update e não tenho certeza se ele irá com um delete sendo que é o mais fácil.

Adicionei a função de section para 'proteger' algumas partes do código e não adicionei onde tem relação a reservas das salas porque as mesmas ainda não foram finalizadas.